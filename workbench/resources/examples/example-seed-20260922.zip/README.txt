WORKBENCH SAVED BUSINESS SNAPSHOT

Read the four databases with any SQLite reader in read-only mode; Workbench is
not required. Manifest file sizes and SHA-256 values verify the exact contents.
Its database entries give user_version, schema hashes and table inventories.
The full schema is readable in each file's sqlite_master table.

OWNERS
system1.sqlite: sources, source_versions, operations, source history/assessments.
system2.sqlite: material_revisions and retained branch-prefixed material tables.
system3_requirements.sqlite: requirement_steps and current Requirement heads.
system3_scd.sqlite: interpretation_history, saved S/C/D heads and source indexes.

TRACE A SAVED CHECK DESIGN
1. Read interpretation_history.body (JSON) in system3_scd.sqlite.
2. Use session_id and session_revision to find the exact requirement_steps row
   in system3_requirements.sqlite. Its body preserves units, Groups and links.
3. Follow material_id/material_revision to System2 material_revisions.data,
   including the branch tables listed in the manifest binding. Source segments
   identify the contributing blocks and their original location references.
4. Follow source_id, snapshot_id and content_hash to System1 source_versions;
   the manifest originals list supplies the matching file under sources/.
5. Foreign versions retain their original authors/time in received_history.
   received_sources and received_assets bind retained content-addressed files.

Saved JSON/history is authoritative; structure/citation tables are derived
indexes. Each logs/*.jsonl file is derived from the corresponding database and
contains actor, time, object identity, action, versions and operation identity.

S/C/D IS A CHECK DESIGN, NOT AN EXECUTED COMPLIANCE RESULT.
A delivery is a fixed artifact and cannot be merged through Collaboration.
A collaboration package must use preview/conflict resolution and explicit
apply in Workbench. Never replace local databases with these snapshots.
Credentials, local runtime configuration and diagnostic logs are excluded.
