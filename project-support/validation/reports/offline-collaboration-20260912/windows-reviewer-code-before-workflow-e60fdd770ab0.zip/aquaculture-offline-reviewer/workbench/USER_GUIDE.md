# Local Workbench User Guide

## Human-led material workspace

This section describes the implemented material interface and its intended operation. It is a usage guide, not an acceptance or runtime-activation claim. Check [PROJECT_STATE.md](PROJECT_STATE.md) and the [workstream state](../PROJECT_STATE.md) for the currently loaded version and dated evidence. The [human-led goal](../docs/design/human-led-workbench-goal.md) governs current scope; the legacy workflows later in this guide retain their own history and compatibility meaning.

Open [Open Workbench.command](../Open Workbench.command), select the named reviewer and enter the material workspace. System1 remains the source-management area. Open an existing material, or use **Open a source snapshot** to choose a governed saved source. The active source version stays visible. Opening creates no extraction or structured Requirement result.

### Read and correct one material

The workspace contains **Original document**, **Extracted original text** and **Structured requirements**. Each pane scrolls independently; drag the separators to change widths. The Materials list and navigation can be collapsed. At narrow widths, use the clearly labelled pane buttons.

1. Read the saved original in the left pane. PDF opens as a saved-page image: use **Previous**, **Next**, **Page** and **Go**, with the full page count and **Zoom** controls. Scroll within a magnified page. Use **Location** for HTML, or **Sheet**, **Row** and **Column** for Excel. **Open original** retains access to the untouched file.
2. Choose **Extract** when you want a machine candidate. Your saved human content remains unchanged while extraction runs. **Refresh candidate** checks that request's status; opening, scrolling or saving does not start another conversion.
3. Choose **Compare / resolve** to compare the prior candidate, current human work and new candidate. After checking the original, choose **Keep**, **Adopt** or **Edit / merge**. Even the first candidate needs an explicit choice. Candidate adoption does not confirm review.
4. Correct text, block type, heading level/parent, source numbering and order in the middle pane. Use **Split at cursor**, **Merge with next** and the add-content controls for omissions. Tables retain editable cells, row/column controls, merge relationships and notes. Images link to original pages or regions; they are evidence references, not generated illustrations.
5. Keep source links and related-content associations accurate. **Original** on a block navigates to its recorded page, HTML location or worksheet range. If a precise location is unavailable, inspect the complete original and correct the association rather than assuming one.

### Save, resume and confirm

**Save material** durably saves partial content, issues and checked scope. It does not mean review is complete. Check the visible unsaved/saving/saved/error state. A failed save leaves the local draft available. Save before switching materials, leaving the workspace or changing the reviewer. Browser draft recovery supplements the server save; it does not replace it.

Browser recovery is local to the current browser profile and origin (including the service port), named reviewer, material and editing tab. Small drafts use browser local storage; large drafts use IndexedDB. **local recovery saving** means the browser write is still pending; keep the page open. **local recovery saved** appears only after the local write succeeds. On reload, the workspace reads the recovery record before announcing recovery. If browser storage is unavailable, the warning tells you to keep the page open and use **Save material**; a failed local recovery write does not prevent a server save. Closing or refreshing while the latest write is pending can lose those latest unsaved edits despite the close-page warning.

Each tab keeps its own recovery record. A browser Web Lock prevents a duplicated or opener-created tab from sharing a live tab’s writable record; refreshing keeps that tab’s owner identity. If Web Locks are unavailable, each document uses a fresh owner and reads its previous document’s record for recovery, without deleting another live tab’s record. A separate reference for each reviewer and material changes only after a successful local journal write, so repeated refreshes without editing still recover the last written draft even when another tab has a newer shared draft. If that tab has no draft, it can offer another tab's draft for the same reviewer and material; a newer server revision requires comparison before merging. Switching reviewer, browser profile or service port does not move recovery records. Clearing browser data removes them. Local recovery is not a server save and is not included in the server backup package. Save each material on the server before backing up or moving the workbench.

Reopen the material to recover its saved version. **History** displays earlier revisions and recorded actions. **Restore this version as a new draft** creates editable work for a later save; it does not reactivate a historical confirmation. **Review existing work** opens retained legacy review, while **Import existing content** brings available earlier effective content into a separate candidate. Old automatic or human A/B decisions remain historical and do not become new whole-material confirmations.

At the end of the middle pane, complete **Whole-material review**. Inspect every required original range, including PDF pages or worksheets where extraction found nothing. Correct omissions, resolve content issues and check source associations/dependencies. Save that work, then use **Confirm content review** and make the explicit final human confirmation. The server checks the saved version, full scope, substantive issues and current System1 source status. Machine scores and block counts cannot complete this review.

An original that is incomplete, unreadable or incorrect needs **Report original problem to System1**. Describe the location and problem. This creates local source follow-up; it does not replace the original or mark the issue resolved. Source follow-up must be resolved before content confirmation.

The completed content label is **Content review complete · Requirement structuring not connected**. The third pane remains **Not connected** and **Process** is disabled because the final structure and processor have not been supplied. No final Requirement form/schema or semantic result is claimed.

### Changes, conflicts and failed extraction

The middle pane opens in **Reading** mode. Use a block's **Edit** control for a focused correction, or switch to continuous editing. Content search covers the entire draft, including blocks outside the current page; chapter navigation uses its recorded headings. Large tables display bounded row/column windows. Edits in earlier windows remain in the same draft when navigating or searching.

Use a block's original link to locate its evidence; where several links exist, choose the intended original range. From the original reader, inspect the linked content for the current page/location. PDF region selection supports dragging a rectangle and entering numerical bounds. A rectangle preserves an original image association; it does not recognize text or perform OCR.

After saving a correction, **Review impact** explains which original ranges need another check. Provably unaffected checks retain their previous reviewer/version provenance. Changes with uncertain impact still require full review. Every body change or withdrawn check revokes final confirmation; the last valid confirmation remains in history. Complete the remaining checks on the saved version and confirm explicitly again.

If an older open tab reports that the material interface was updated, refresh it and recover its retained local draft. The server refuses old-client mutations rather than allowing an outdated candidate comparison to submit decisions.

Re-extraction creates another candidate. It never overwrites human text, deletes omitted blocks or updates downstream content automatically. An upstream source change flags the affected workspace as stale while preserving its body and history. Open the newer snapshot and compare the retained work against it. A result produced from an older input stays labelled stale.

If another tab or reviewer saved a newer revision, the workbench retains your local draft and offers a comparison with the newer server version. Reconcile and save a new revision; repeated requests must not duplicate saved operations. After extraction failure or a service restart, saved human work and request/history records remain separate from the failed or pending candidate.

### Original-reading limitations

| Original | What the reader provides | What the reviewer must distinguish |
| --- | --- | --- |
| PDF | Saved-page images with Previous/Next/Go navigation, full page count, zoom and within-page scrolling; separate selectable native-text assistance when available | Page images are not selectable text. Native text is unverified assistance and may differ from visible marks, including hidden text. Inspect the image and manually transcribe or supplement omissions. **Optional browser PDF viewer** is loaded only when opened; it depends on the browser plugin and may be blank or unavailable. Use the default image reader in that case. This material route does not run OCR. |
| HTML | Complete isolated saved markup with selectable text, headings, tables and stable locations | Scripts, source styles and external assets are disabled. Static disclosures are opened. Missing images or layout differences remain visible limitations; no live website replaces the snapshot. |
| XLSX | Worksheet switching, continuing rows/columns, cell addresses, merge relationships, formulas and saved values | Missing caches are not calculated. Hidden content is labelled and remains navigable. Native styling, drawings, charts and conditional presentation are not reproduced. Inspect the preserved original for those features. |
| XLS | Preserved download and explicit compatibility notice | A human-created XLSX parsing copy needs recorded lineage; no silent conversion occurs. |

The [material interface guide](../system2/docs/contracts/human-material-workbench.md) documents service boundaries, source references, worker behavior and isolated engineering commands.

## Retained System1 and legacy review reference

The dated sections below describe existing System1 operations and retained older System2 A/B interfaces. They do not supersede the material workflow above or establish new runtime/quality acceptance. Legacy classification and output operations are separate compatibility actions.


## Saved decisions and source-aware Excel status | 2026-09-10

System1 and System2 show saved decisions separately from their Excel snapshots. System2 also checks the current source version: a source-information change can make Excel pending even when no content decision changed. Failed, missing or stale source checks show an unconfirmed status; already saved decisions and the previous verified download remain available. Synchronization and retries run in the background.

## Original-page comparison | 2026-09-10

In System2 Content proofreading, choose Inspect original PDF pages, open a page and select Check this original page. The saved comparison includes original-region highlights, correction drafts and explicit unverified scope. Recheck after modifying content. A saved correction is not A/B acceptance. Excel synchronization status shows the database and snapshot versions separately. See [the comparison workflow and limits](../system2/docs/contracts/original-verification.md). The new stage-specific weekly sampling rules remain pending implementation.

## Legacy two-stage workflow | 2026-09-09

Open the shared launcher and select a named reviewer. System2 → Pending review shows real jobs; choose an INCLUDE source and click Start processing. Confirm full-text coverage and content/structure before classifying Requirements, context and exclusions. Use source evidence, corrections, split/merge or missing-content supplementation where needed. Save draft is not acceptance. Include reviewed content to reopen an earlier result. Pause is checkpoint-based; Request reprocessing preserves the old generation and invalidates its deliveries.

Confidence settings owns all thresholds, initially 95%. Uncalibrated results require manual review regardless of threshold. Raising thresholds reopens affected machine results; human decisions/drafts remain protected. Optional assistance is disabled without explicit configuration. System1 Machine assessments shows evidence-supported five-dimension proposals and preserves named human decisions.

In each System2 task, expand **Scores and evidence by dimension** to inspect A text accuracy, original coverage, structure/relationships and reading order, and B classification, original association and parent/subitem correctness. Missing or unsupported dimensions remain unknown. A human confirmation does not create a machine score; the lowest supported required dimension controls automatic routing.

System2 Weekly checks samples original-side A scopes and completed positive/negative B judgments, including human decisions. Normal A/B activation remains disabled pending authorization. System3 Incoming requirements displays incremental deliveries and source completeness; semantic processing is not connected. Original HTML is a script-free text view, PDF opens its registered full original, and XLSX supports paged cells, formulas/caches, hidden state and merged-region metadata.

See the [current workflow contract](../system2/docs/contracts/two-stage-review.md) for authority, operations and compatibility. Older dated integration/demo descriptions below are historical; they do not replace this workflow.


The daily entry point is [Open Workbench.command](../Open Workbench.command) at the root of `05_Working area of requirements side/`. Double-click it to start the local service and open the default browser; subsequent launches reuse the same service. Closing the browser does not stop submitted jobs. Select “Exit workbench” at the bottom left to stop safely. No login startup or operating-system background service is installed.

## Overview and navigation

The workbench serves the full Requirement workflow across System1, System2 and System3. Requirement overview presents source management, extraction review and semantic completion side by side. Each area shows its responsibility, connection status, pending count, key outputs and entry point. Unconnected metrics display “Not connected”; this does not mean zero tasks or completed work. System2’s “Open review demo” opens a separate demonstration whose activity is excluded from the production overview and weekly accuracy.

Weekly inspection results show completed checks and coverage gaps over the latest five weeks. Monitoring agreement does not establish independent acceptance accuracy. System1 details is collapsed by default. Expand it to see registered sources, pending sources, stored originals, included sources, source selections, pending reasons and source composition. These details use the same System1 snapshot and do not depend on Excel chart caches. Select a pending-reason bar or priority source to open the corresponding list. “Review sources” returns to the complete queue; “Show all” also clears filters.

Select a System in the sidebar to expand or collapse “Pending review” and “Review history”. System1 history combines retained named source-operation records with browser receipts. System2 has live two-stage review; System3 exposes incoming requirements while semantic enrichment remains unconnected.

Counting rules: System1 counts sources, System2 counts extraction review items, and System3 counts semantic completion items. These are not added into a single pending total. System1 pending counts use source IDs. A source may have several issues, so reason bars cannot be summed to obtain the pending total. A stored original indicates storage only, not verified parsing or content.

## Weekly random checks

The workbench service checks for a missing current-week batch while running. Monday targets in Europe/Oslo are System1 5 governance records, System2 A 20 original inspection units and System2 B 5 completed classification judgments; System3 is off. System1 retains its existing schedule. Normal A/B activation remains pending explicit authorization. A running interface does not activate it. An enabled stage catches up only the current week after downtime. Preserve the owning databases, managed originals and histories when migrating the project so batches are not sampled again.

System1 randomly samples currently effective included sources with no unresolved tasks, excluding items still awaiting a previous check. If fewer than five are eligible, it samples all and records the actual count; zero eligible items produce an empty batch. Tasks appear under System1 → Pending review. Dashboard’s “System1 checks” opens the filtered list. Check the links, original and register details, then select “Correct”, or enter a note and select “Report an error”. An error creates a corrective task.

In System2 choose Weekly checks, then Pending or Review history. A shows complete original scopes even when nothing was extracted; B retains positive and negative classifications where available. Compare the original on the left with the result on the right, add the exact evidence and record agreement, a problem or an unverified result. Reported problems stay pending. Open the repair task, correct the ordinary A/B result, then return to record a separate follow-up. B shows the current subdivision/counting policy during follow-up. Failed submissions retain the draft. Earlier machine-only checks remain separately available.

The overview displays the current week and four preceding weeks. Observed agreement is initially correct items divided by sampled items, displayed only after the target is met and all findings are resolved. Missing B classes, short samples, catalog failures and unfinished checks remain explicit. This monitoring measure is not independent acceptance accuracy. Excel contains a one-way Weekly checks audit sheet after background synchronization. See the [sampling contract](../system2/docs/contracts/weekly-original-sampling.md) for original-unit definitions and limits.

System1 is currently connected. System2/3 display “Not connected” until they provide production task and decision interfaces. No operating-system background task or Codex automation was created. Run this service on the deployment device.

## System2 repairs and previous decisions

Use the [System2 daily repair guide](../system2/USER_GUIDE.md#daily-repairs-source-follow-up-and-history) for failed-original follow-up, scan transcription and linked source context. The same screen supports table cells, rows, shared cells, footnotes and cross-page context; there is no Excel decision entry. For an original empty cell use **Clear cell text** and supply the source evidence before applying.

In **Review history**, expand a decision and choose **Open current result to review**. This opens its current A or B state without applying a change. The saved human classification is displayed and remains selected until explicitly replaced. New B entries retain classification before/after, time and source version; unavailable older fields are not inferred. The source can remain incomplete while an individually checked Requirement is available.

## Daily operation

1. At the top right, select Ana Jokic, Daniel Restad or Weijie Tang, listed alphabetically by first name, then select “Use this name” or “Switch reviewer”. This identifies the operator on a trusted local machine; it is not password authentication. Switch names when the operator changes.
2. Select a System1 task and inspect the official page, registered retrieval link and local original. PDFs open in a full reader with paging, zoom, search and a separate-window option. The reader verifies the registered version and file fingerprint. HTML has a read-only text preview; open the original through the download link. Source scripts do not execute in the workbench.
3. When scoring is required, select H / M / L for each criterion. Light styling shows the previous score; dark styling shows this review’s selection. A previous score is not confirmation. All five selections trigger submission automatically. Scoring and original-file gates remain separate.
4. Deferring a source or removing it from scope requires a reason. Notes save automatically as drafts; saving a draft does not complete a decision.
5. Correcting a link saves register information only. It does not download a file or claim verification. After checking a reported issue, mark it verified, enter the evidence and record the verification result.
6. Replacement files are staged locally first. After the initial format check, a person confirms identity, completeness and usage permission before submitting acceptance. System1 validation and snapshot rules still apply. A format check does not prove regulatory identity or semantic completeness.
7. Recent submissions show submitted, applying, waiting for release, applied, needs attention or stale-page states. System1 database decisions save independently of Excel. Its saved/exported revision bar distinguishes pending, synchronizing, synchronized and failed output; closing Excel permits automatic synchronization. If the submission result is unknown, “Retry submission” reuses the original request ID. Stale or field-invalid decisions remain available; reload and check them again. A source-version change preserves note and corrected-link drafts while clearing confirmation of old scores.
8. Review history presents named database operation history and browser requests, including retained imported workbook history. Complete sources and receipts are retained; the interface is not a second source register. Imported Excel reviews display the original ACCEPT / REJECT / INCORRECT result and notes. If the original has no review date, the displayed date is explicitly the synchronization time. Sources with remaining tasks show colleagues’ previous decisions and the unresolved reasons. An old ACCEPT does not backfill five-criterion scores.

Connected source actions cover scoring, selection, link correction, verification of reported issues, replacement files and random checks for enrolled sources. New discovery/registration is outside the current authorized scope. System2 has live processing and two-stage review; System3 semantic processing remains unconnected. The retained sample practice below is historical.

## Historical System2 review demo

System2 → Pending review uses the same vertical queue and search field as System1. Items display their source ID, title and pending status. Only unfinished and “Needs follow-up” items remain in the queue. Completed items move to Review history, where the original and decision details remain accessible. “Reopen sample” returns an item to pending review.

Five samples demonstrate PDF text checking, sentence joining, omitted tables, HTML list relationships and Excel header ownership. For PDFs, the historical source page and red box appear on the left, with zoom and full-page viewing. On the right, “Accept & next” or “Correct text” advances after saving. An omitted table records its scope and requests reparsing without requiring transcription of the whole page. Illegibility, omissions and reparse requests remain follow-up items, not accepted reviews.

“Screenshot does not match? Open full PDF” expands the full reader while preserving the draft on the right. “Choose PDF” selects the same original from the desktop and checks the PDF header and complete SHA-256. A matching file is displayed only in the browser and is not uploaded. Page buttons are English; the operating system controls its native file-dialog language. HTML and Excel are clearly labeled synthetic examples, retaining adjacent headings, headers and cell coordinates in the source panel.

Demo drafts and history are stored per operator in the current browser. Refreshing or switching items preserves drafts. Clearing browser data removes practice records; they do not synchronize across devices. The demo does not call production decision, parsing or upload interfaces and does not enter production history or Dashboard accuracy. See the [System2 demo contract](docs/system2-review-demo.md) for boundaries and provenance.

## File ownership

- `ui/`: browser interface.
- `src/local_workbench/`: HTTP service, operator/request storage, serial worker, environment adapters and launcher.
- `runtime/workbench.sqlite`: operators, sessions, note drafts, requests and receipts. This is persistent data that requires backup, not disposable cache.
- `runtime/uploads/`: staged files and source records. Retain pending files and failure evidence.
- `runtime/server.json`, `listen-port.json`, lock files and `service.log`: local runtime information, excluded from shared configuration.
- System1 owns authoritative source state in its configured governance database; Data retains originals and Excel is a protected one-way view. Excel opens Instructions and exposes Instructions, Categories, Source Register and Machine confidence. Dashboard and Human Operation Desktop are `veryHidden` compatibility sheets preserving calculations and review history. Daily dashboards and human actions use the browser. Controlled saves maintain this layout; do not delete hidden sheets or rewrite formulas.

This component uses its own `.venv` and the standard library only. Follow the shared [environment guide](../ENVIRONMENT.md#system1-and-the-workbench-on-macos) to recreate the workbench and System1 environments on a new computer. Copying an environment directory is not a portable installation.

Validation commands, run in this directory:

~~~text
PYTHONPATH=src .venv/bin/python -m unittest discover -s tests -v
node --test tests/*.mjs
PYTHONPATH=src .venv/bin/python -m local_workbench --no-browser
~~~

Frontend state tests use the development machine’s existing Node.js; it is not part of the production Python environment.

The service listens only on `127.0.0.1`, preferring the previous port recorded in runtime and choosing an available port if occupied. A port change creates a separate browser storage space; demo records remain in the old space. POST requests validate Host, Origin, CSRF and the local session. Originals are not sent externally. Remote access, automatic downloading, external models, full parsing and publication are not authorized.

See [PROJECT_STATE.md](PROJECT_STATE.md) for current status and [Workbench design](docs/local-workbench-design.md) for design rationale. The shared operating rules are in [AGENTS.md](../AGENTS.md) at the `05` workspace root.

## Requirement subitems in B

In **System2 → Pending review → Requirement judgment**, a content item that passed A can use **Create / replace requirement subitems**. Add exact original selections or unique pasted quotations. The complete parent and its shared footnotes remain available. Review unassigned text, choose a provisional count rule, and submit the decision. Generated subitem labels are never original source numbers.

Accepted items can be reopened through **Browse all original content**. Replace the subdivision or choose **Remove subitems and classify the complete parent**; both preserve history. If original content or related footnotes change, recheck A and then B before delivery resumes. Drafts and rejected submissions do not complete the task. Excel shows saved parent/subitem counts after background synchronization. [The B contract](../system2/docs/contracts/requirement-subdivision.md) states current limits and pending peer decisions.

## Runtime status

**Runtime status** shows Source service, Material extraction, Saved material storage, Excel output, Source Excel output and Legacy processing separately. It reports the current operation, last check/success, running duration and any sanitized failure. A successful later check clears the active error; the prior error remains available for diagnosis after recovery or restart. A version conflict or known form validation refusal is not an infrastructure outage. Unknown failures, database errors and timeouts remain visible.

`GET /health` identifies the local service and loaded source version; it is not a complete readiness check. `GET /api/runtime-status` provides component evidence and a read-only saved-store probe. Runtime evidence is persisted in `runtime/runtime-status.json`; `runtime/runtime-events.jsonl` records failure/recovery transitions. Neither stores document bodies or raw exception text. Request identifiers, when available, link failures to an action receipt. Successful heartbeat writes are throttled. A failure to persist monitoring evidence is itself shown in the response.

Existing background checks use bounded infrastructure backoff. Extract consumes only explicitly submitted, durable candidates. A failed parser result requires another explicit Extract action, producing a new candidate; viewing Runtime status cannot enqueue extraction. Interrupted pending candidates resume under the owning worker lock. A stopped worker or unreadable saved store is reported rather than treated as healthy. Process-lifetime peak resident memory, thread count and uptime support diagnosis; peak memory is not current memory or proof of a leak.

## Explicit local backup and restored inspection

Save browser drafts, close Excel, use **Exit workbench**, and wait for all processing to finish before backup. The tool refuses an active service, another process writer, a busy owning database, missing Canonical evidence or a missing immutable governance companion. It holds process locks and simultaneous writer reservations on the five owning databases plus the optional System2 job database when present while taking SQLite backup snapshots and copying required resources. If an asset changes during copying, the package remains incomplete and cannot be restored. It does not install a schedule or delete previous packages.

Run from the workstream root, replacing the destination with a new local directory:

```sh
PYTHONPATH=workbench/src workbench/.venv/bin/python -m local_workbench.recovery backup --root "$PWD" --destination /path/to/new-backup
PYTHONPATH=workbench/src workbench/.venv/bin/python -m local_workbench.recovery verify /path/to/new-backup
PYTHONPATH=workbench/src workbench/.venv/bin/python -m local_workbench.recovery restore /path/to/new-backup --destination /path/to/new-restored-workspace
PYTHONPATH=workbench/src workbench/.venv/bin/python -m local_workbench.recovery serve-restored /path/to/new-restored-workspace --code-root "$PWD"
```

The package includes the configured source-governance, source-assessment and Leader databases, the System2 workflow database, the optional System2 job database when present, workbench requests/drafts/policies, source Data, immutable migration companion, referenced Canonical evidence, material originals/artifacts, uploads and owning operational logs. The v2 manifest records file hashes, sizes, references, creation time and code revision. A separate `code/` archive stores the exact local source, UI assets, parser schemas/configurations, public configuration examples, dependency declarations/locks, setup scripts and `ENVIRONMENT.md`. This preserves uncommitted source bytes independently of Git HEAD. Live provider configuration, `.env`, component environments and caches are excluded. Source changes during copying or mismatched source hashes make verification fail. Unrelated old acceptance backups and rebuildable environments/caches are not recursively copied. Browser-local unsaved drafts are outside the server backup.

Restore requires a new destination and verifies every file and database before exposing it. Database payloads and history remain byte-identical; `recovery-mapping.json` records the old and restored roots without rewriting human history. The inspection service links the existing project's code/environments, runs against restored configuration and data, and disables background workers, business actions and legacy evidence endpoints that could follow old absolute paths. Material history, saved content, bound originals and readers are available for inspection on a separate loopback port. The package and original data directories are not required for those material reads after restore. Stop the inspection process after validation.

If the original code changes or is no longer available, extract the verified source archive into another new directory:

```sh
PYTHONPATH=workbench/src workbench/.venv/bin/python -m local_workbench.recovery extract-code /path/to/new-backup --destination /path/to/matching-code
```

Recreate the three component environments using **the extracted** `/path/to/matching-code/ENVIRONMENT.md`, its System1 pinned requirements and setup script, System2 `pyproject.toml`/`uv.lock`, and Workbench `pyproject.toml`. Do not launch the normal workbench from this code-only tree. Once environments are available, run the matching recovery module with `--code-root /path/to/matching-code`:

```sh
PYTHONPATH=/path/to/matching-code/workbench/src /path/to/matching-code/workbench/.venv/bin/python -m local_workbench.recovery serve-restored /path/to/new-restored-workspace --code-root /path/to/matching-code
```

The inspector verifies the selected code against the archived runtime/dependency fingerprints before linking it. Source extraction does not install packages, run setup scripts, apply business decisions or enable scheduling. Older v1 packages still verify their business files but do not contain a source archive; `extract-code` explicitly refuses those packages.

This is an isolated restoration and inspection path. Replacing a live workspace, enabling restored writers or migrating legacy absolute references into a new operational deployment requires a separate, explicit operational action. The package contains recoverable source and dependency declarations, not installed interpreters, native tools, downloaded libraries or models. Rebuilding environments on a new machine remains a separate installation step; the isolated acceptance exercise reused existing component environments while loading source from the recovered archive.

## Offline review with colleagues

Use **Open Reviewer Workbench.cmd** on Windows for a reviewer-only workspace. Follow [Windows setup and actual acceptance](docs/windows-offline-review-checklist.md). The ordinary launcher opens the coordinator workspace; those modes are deliberately separate.

1. In the main workspace, Weijie Tang selects an existing source/material and chooses **Create work package**. Give that ZIP to colleagues manually.
2. Each colleague imports it into their own reviewer workspace and selects their real name. **Save material** and **Source review → Save** preserve personal progress. Neither changes the coordinator's main version.
3. Read the original beside the editable text. **Extract** creates a candidate. Compare differences inline and explicitly keep, choose or edit; current human content is retained until application. A resolved identical candidate does not repeatedly demand the same decision.
4. **Export my submission** freezes the saved personal result with its history. An incomplete result can be returned with its remaining scope and issues.
5. In the main workspace, **Import package → Submission inbox → Review submission** opens a merge preview. Disjoint edits appear as pending contributions; conflicting paragraphs, cells and source fields display both versions. Choose **Keep current**, **Adopt submitted**, or **Edit result** at each difference.
6. **Adopt reviewed result into master** creates the new main version and separate source/content receipts. Source partial success is shown separately. **View master → Confirm master content review** is a later, explicit complete-original check.

The coordinator also saves into personal work and uses **Review my changes** before main adoption. No one's local SQLite database should be returned or merged. A work package contains the selected original; a return package cannot create sources or replace originals. Bound-original image references remain linked to that original. External assets are not fetched automatically.

A reviewer's confirmation applies to their saved version. The combined main version inherits only valid unaffected checks and remains unconfirmed until its own full-range confirmation. Main version changes after a preview require a new comparison. Received packages, saved choices and prior versions remain available after failures and restart.

## Unified navigation

Use **Source Management System** for source management and **Requirement Extraction System** for the three-pane human workbench. There is no standalone System3 queue or incoming-feed entry. Structured requirements is the reserved third pane inside Materials; Process remains disabled. Historical backend records and design interfaces are retained.

## Material archive, spot-checks and working space

**Pending materials** contains unfinished work, conflicts and open spot-checks. **Archive** displays an explicitly accepted and fully human-confirmed main version. Personal save/confirmation alone does not archive a material. Both categories use the same workbench.

From Archive, **Create spot-check** selects a named reviewer, reason and original ranges. Its task returns to Pending; the accepted archive remains visible and unchanged. **Save check progress** permits partial work. **Pass selected checks** needs the selected range checks, evidence note and explicit human confirmation. **Record a problem** retains an open finding. After main content repair, review the current main and explicitly resolve the finding; whole-material confirmation is still separate. If another accepted version supersedes a pending check, **Restart check on latest archive** preserves the old record and starts fresh coverage. These tasks are local records; ZIP exchange of spot-check tasks is not connected yet.

**Expand workspace** fills the browser window. **More tools** temporarily reveals auxiliary controls. Exit with **Exit expanded view** or Escape. Drag the two vertical separators to adjust all three pane proportions. You can also focus a separator and press Left/Right, with Shift for larger steps. The browser remembers your widths; **Reset column widths** restores defaults. Layout changes preserve editing state and never invoke Extract or Process. Narrow windows switch between panes.
