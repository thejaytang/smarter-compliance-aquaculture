# Windows environment reconstruction kit

Use with application commit 3d0289865328a2d03227892a9775f111625eb885 or a compatible later version.

Follow ENVIRONMENT.md and workbench/docs/windows-colleague-guide.md in your repository clone. This kit contains setup scripts, dependency declarations and instructions. It does not contain Python, binary wheels, native OCR tools, virtual environments or business data. A rebuild needs package repository access.

Never overwrite live configuration or restore initial data during an application update.
