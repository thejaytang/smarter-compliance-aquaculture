# Material idle dispatch handoff

This is a partial performance fix, not a Windows acceptance result.

1. Export and preserve all uncommitted Windows changes and new files first. In particular, retain operation_gate.py and the Windows SQLite URI fix.
2. Use the included baseline collaboration.py to merge only the tick change with the Windows file. Do not overwrite the Windows file with the updated copy. Add the new helper and test/profile files only after checking for name conflicts. Review the contract patch.
3. From the Windows repository root, run the following in Command Prompt using the existing environment. Tests use isolated temporary data and do not restore a seed or access live materials.

```bat
set "PYTHONPATH=workbench;workbench\backend\application;workbench\tests"
workbench\.venv\Scripts\python.exe -m unittest -v test_material_activity
workbench\.venv\Scripts\python.exe workbench\tests\integration\material_idle_profile.py --output "%TEMP%\workbench-idle-native.json"
```

Use a fresh output filename if it already exists. Return the JSON and test output. native_windows must be true for a Windows result. This profile covers idle dispatch only; actual browser material-open/save/reopen timings and pending-job recovery still require native verification.

No business database, private settings, source originals, environment or runtime state is included. This archive does not provide the Windows-only changes that have not yet been transferred.
