"""Single-user local workbench."""
